"""Simple TTL cache for expensive lookups."""

import time
import functools
from typing import Any, Dict, List, Optional, Callable, TypeVar

class TTLCache:
    def __init__(self, ttl_seconds: int = 300, max_size: int = 1000) -> None:
        self.ttl: int = ttl_seconds
        self.max_size: int = max_size
        self._store: Dict[Any, tuple[Any, float]] = {}

    def get(self, key: Any) -> Any:
        entry: Optional[tuple[Any, float]] = self._store.get(key)
        if entry is None:
            return None
        value, expires_at = entry
        if time.time() > expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: Any, value: Any) -> None:
        if len(self._store) >= self.max_size:
            self._evict_expired()
            if len(self._store) >= self.max_size:
                oldest_key = min(self._store, key=lambda k: self._store[k][1])
                del self._store[oldest_key]
        self._store[key] = (value, time.time() + self.ttl)

    def delete(self, key: Any) -> None:
        self._store.pop(key, None)

    def clear(self) -> None:
        self._store.clear()

    def _evict_expired(self) -> None:
        now = time.time()
        expired = [k for k, (_, exp) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]

    @property
    def size(self) -> int:
        return len(self._store)

    def stats(self) -> Dict[str, int]:
        now = time.time()
        active = sum(1 for _, (_, exp) in self._store.items() if now <= exp)
        return {"total_entries": len(self._store), "active": active, "expired": len(self._store) - active}


_default_cache: Optional[TTLCache] = None


def get_default_cache(ttl: int = 300) -> TTLCache:
    global _default_cache
    if _default_cache is None:
        _default_cache = TTLCache(ttl_seconds=ttl)
    return _default_cache


def cached(ttl: int = 300) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that caches function results based on arguments."""
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        cache = TTLCache(ttl_seconds=ttl)

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            cache_key = str(args) + str(sorted(kwargs.items()))
            result = cache.get(cache_key)
            if result is not None:
                return result
            result = fn(*args, **kwargs)
            cache.set(cache_key, result)
            return result

        wrapper.cache = cache
        wrapper.cache_clear = cache.clear
        return wrapper
    return decorator
