"""CSV file ingestion source."""

import csv
import os
from datetime import datetime
from typing import Any, Dict, List, Optional, Generator

from .models import Record

def iter_records(path: str, delimiter: str = ",", encoding: str = "utf-8") -> Generator[Record, None, None]:
    """Read CSV file and yield Record objects."""
    with open(path, encoding=encoding) as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        line_num = 0
        for row in reader:
            line_num += 1
            parsed = _coerce_row(row, line_num)
            if parsed is not None:
                yield Record.from_dict(parsed)


def _coerce_row(row: Dict[str, str], line_num: int) -> Optional[Dict[str, Any]]:
    """Convert string values to appropriate Python types."""
    result: Dict[str, Any] = {}
    for key, value in row.items():
        if value is None or value.strip() == "":
            result[key] = None
            continue

        value = value.strip()

        # Try numeric conversion
        converted = _try_numeric(value)
        if converted is not None:
            result[key] = converted
            continue

        # Try date parsing
        parsed_date = _try_parse_date(value)
        if parsed_date is not None:
            result[key] = parsed_date
            continue

        # Try boolean
        if value.lower() in ("true", "false", "yes", "no", "1", "0"):
            result[key] = value.lower() in ("true", "yes", "1")
            continue

        result[key] = value

    result["_source"] = "csv"
    result["_meta"] = {"file": os.path.basename("unknown"), "line": line_num}
    return result


def _try_numeric(value: str) -> Optional[float]:
    """Try to convert a string to int or float."""
    try:
        if "." in value:
            return float(value)
        return float(int(value))
    except (ValueError, TypeError):
        return None


def _try_parse_date(value: str) -> Optional[str]:
    """Try common date formats."""
    formats = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%m/%d/%Y", "%d-%b-%Y"]
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt).isoformat()
        except ValueError:
            continue
    return None


def read_csv_batch(path: str, batch_size: int = 1000, skip_header: bool = False) -> Generator[List[Record], None, None]:
    """Read CSV in batches, yielding lists of records."""
    batch = []
    for record in iter_records(path):
        batch.append(record)
        if len(batch) >= batch_size:
            yield batch
            batch = []
    if batch:
        yield batch


def detect_delimiter(path: str) -> str:
    """Guess the delimiter by reading the first line."""
    with open(path) as f:
        first_line = f.readline()
    for candidate in [",", "\t", "|", ";"]:
        if candidate in first_line:
            return candidate
    return ","


def count_rows(path: str, delimiter: str = ",") -> int:
    """Count data rows (excluding header) in a CSV file."""
    with open(path) as f:
        reader = csv.reader(f, delimiter=delimiter)
        next(reader, None)  # skip header
        return sum(1 for _ in reader)
