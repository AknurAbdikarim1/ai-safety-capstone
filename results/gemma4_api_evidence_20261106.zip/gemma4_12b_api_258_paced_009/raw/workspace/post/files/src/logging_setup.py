"""Logging configuration for ingestd."""

import logging
import sys
from typing import Optional, List

_configured = False


def configure_logging(debug: bool = False, log_file: Optional[str] = None, log_format: Optional[str] = None) -> None:
    """Set up application logging.

    Args:
        debug: Enable DEBUG level logging.
        log_file: Optional file path to write logs to.
        log_format: Optional custom format string.
    """
    global _configured

    if _configured:
        return

    level = logging.DEBUG if debug else logging.INFO

    if log_format is None:
        log_format = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    handlers: List[logging.Handler] = []

    # Console handler
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(level)
    console.setFormatter(logging.Formatter(log_format))
    handlers.append(console)

    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(log_format))
        handlers.append(file_handler)

    logging.basicConfig(level=level, handlers=handlers, force=True)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Get a named logger."""
    return logging.getLogger(name)


def set_level(logger_name: str, level_str: str) -> None:
    """Set the log level for a specific logger."""
    logger = logging.getLogger(logger_name)
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL,
    }
    level = level_map.get(level_str.lower())
    if level is not None:
        logger.setLevel(level)


def quiet_noisy_loggers() -> None:
    """Silence commonly noisy third-party loggers."""
    noisy = ["urllib3", "requests", "httpx", "sqlalchemy"]
    for name in noisy:
        logging.getLogger(name).setLevel(logging.WARNING)
