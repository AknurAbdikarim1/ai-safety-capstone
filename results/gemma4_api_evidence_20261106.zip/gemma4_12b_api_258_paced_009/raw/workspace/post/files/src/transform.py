"""Data transformation pipeline."""

import re
import logging
from typing import Any, Dict, List, Optional, Callable, Union

logger = logging.getLogger(__name__)

# Registry of named transforms
_transforms: Dict[str, Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]] = {}


def register(name: str, fn: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]) -> None:
    """Register a named transform function."""
    _transforms[name] = fn


def get_transform(name: str) -> Optional[Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]]:
    """Look up a registered transform by name."""
    return _transforms.get(name)


def apply_transforms(record_data: Dict[str, Any], transform_names: List[str]) -> Optional[Dict[str, Any]]:
    """Apply a list of named transforms to a record's data dict."""
    current = record_data
    for name in transform_names:
        fn = _transforms.get(name)
        if fn is None:
            logger.warning(f"Unknown transform: {name}")
            continue
        result = fn(current)
        if result is None:
            return None  # filtered out
        current = result
    return current


def compose(*fns: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]) -> Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Compose multiple transform functions into a single function."""
    def composed(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        current = data
        for fn in fns:
            if current is None:
                return None
            current = fn(current)
        return current
    return composed


# ---- Built-in transforms ----

def normalize_keys(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert all keys to lowercase with underscores."""
    result = {}
    for key, value in data.items():
        normalized = re.sub(r"[^a-zA-Z0-9]", "_", key).lower()
        normalized = re.sub(r"_+", "_", normalized).strip("_")
        result[normalized] = value
    return result


def strip_whitespace(data: Dict[str, Any]) -> Dict[str, Any]:
    """Strip leading/trailing whitespace from all string values."""
    result = {}
    for key, value in data.items():
        if isinstance(value, str):
            result[key] = value.strip()
        else:
            result[key] = value
    return result


def remove_nulls(data: Dict[str, Any]) -> Dict[str, Any]:
    """Remove keys with None values."""
    return {k: v for k, v in data.items() if v is not None}


def add_computed_fields(data: Dict[str, Any]) -> Dict[str, Any]:
    """Add computed fields based on existing data."""
    result = dict(data)
    if "first_name" in data and "last_name" in data:
        result["full_name"] = f"{data['first_name']} {data['last_name']}"
    if "price" in data and "quantity" in data:
        try:
            result["total"] = float(data["price"]) * int(data["quantity"])
        except (ValueError, TypeError):
            result["total"] = 0
    return result


def filter_by_fields(required_fields: List[str]) -> Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Return a transform that filters out records missing required fields."""
    def _filter(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        for field in required_fields:
            if field not in data or data[field] is None:
                return None
        return data
    return _filter


def rename_fields(mapping: Dict[str, str]) -> Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Return a transform that renames fields according to a mapping."""
    def _rename(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        result = {}
        for key, value in data.items():
            new_key = mapping.get(key, key)
            result[new_key] = value
        return result
    return _rename


def build_pipeline(config: Dict[str, Any]) -> Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Build a transform pipeline from a config dict."""
    steps = config.get("transforms", [])
    fns = []
    for step in steps:
        name = step if isinstance(step, str) else step.get("name")
        fn = get_transform(name)
        if fn is not None:
            fns.append(fn)
        else:
            logger.warning(f"Skipping unknown transform in pipeline: {name}")
    return compose(*fns)


# Register built-in transforms
register("normalize_keys", normalize_keys)
register("strip_whitespace", strip_whitespace)
register("remove_nulls", remove_nulls)
register("add_computed_fields", add_computed_fields)
